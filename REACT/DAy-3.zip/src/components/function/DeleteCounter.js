import React from "react";
import { useCounterContext } from "../../context/CounterContext";

function DeleteCounter(props) {
  let { deleteCounter } = useCounterContext();
  return (
    <>
      <button onClick={() => deleteCounter(props.index)}>Delete</button>
    </>
  );
}

export default DeleteCounter;
