import React from "react";
import { useCounterContext } from "../../context/CounterContext";
import DeleteCounter from "../function/DeleteCounter";

function Counter({ count, index }) {
  let { incCounter, resetCounter } = useCounterContext();
  return (
    <>
      <h1>{count}</h1>
      <button
        onClick={() => {
          incCounter(index);
        }}
      >
        Click
      </button>
      <button onClick={() => resetCounter(index)}>Reset</button>
      <DeleteCounter index={index} />
    </>
  );
}

export default Counter;
