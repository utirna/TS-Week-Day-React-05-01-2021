import React from "react";
import DeleteCounter from "../function/DeleteCounter";

class CounterClass extends React.Component {
  constructor() {
    super();
  }

  render() {
    let { count, incCounter, resetCounter, index, deleteCounter } = this.props;

    return (
      <>
        <h1>{count}</h1>
        <button
          onClick={() => {
            incCounter(index);
          }}
        >
          Click
        </button>
        <button onClick={() => resetCounter(index)}>Reset</button>
        <DeleteCounter deleteCounter={deleteCounter} index={index} />
      </>
    );
  }
}

export default CounterClass;
