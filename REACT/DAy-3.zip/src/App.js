import React from "react";
import { useCounterContext } from "./context/CounterContext";
import Counter from "./components/function/Counter";

function App() {
  let { counters } = useCounterContext();
  return (
    <>
      {counters.map((counter, index) => (
        <Counter key={index} count={counter.count} index={index} />
      ))}
    </>
  ); // JSX Javascript XML
}
// useContext hooks states
// redux lib states
export default App;
