// imports
import React, { createContext, useContext } from "react";

// create Context
let CounterContext = createContext({});

// create & export Provider
export function CounterContextProvider(props) {
  let { children } = props;

  let setValue = -5;
  let [counters, setCounter] = React.useState([
    {
      count: 2,
    },
    {
      count: 4,
    },
    {
      count: 5,
    },
  ]);

  let incCounter = (index) => {
    let newCounters = [...counters]; // recreated array
    newCounters[index].count += 1; //count inc
    setCounter(newCounters); // assign new counter array to state
  };

  let resetCounter = (index) => {
    let newCounters = [...counters]; // recreated array
    newCounters[index].count = setValue; //reset inc
    setCounter(newCounters); // assign new counter array to state
  };

  let deleteCounter = (index) => {
    console.log(index);
    let newCounter = [...counters];
    newCounter.splice(index, 1);
    setCounter(newCounter);
  };

  let values = {
    counters,
    incCounter,
    resetCounter,
    deleteCounter,
  };
  return (
    <CounterContext.Provider value={values}>{children}</CounterContext.Provider>
  );
}

// create & export Context ( Custom Hook)
export const useCounterContext = () => {
  return useContext(CounterContext);
};
