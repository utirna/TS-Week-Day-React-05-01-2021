import { CounterContextProvider } from "./CounterContext";

const MainContextProvider = ({ children }) => {
  return <CounterContextProvider>{children}</CounterContextProvider>;
};

export default MainContextProvider;
