import React from "react";
import CounterClass from "./components/class/CounterClass";
import Counter from "./components/function/Counter";

function App() {
  let countOne = 5;
  let countTwo = 3;
  return (
    <>
      <Counter count={countOne} />
      <CounterClass count={countTwo} />
    </>
  ); // JSX Javascript XML
}

export default App;
