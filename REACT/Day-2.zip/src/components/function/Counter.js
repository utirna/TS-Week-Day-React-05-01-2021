import React from "react";
// hooks  ---> useState 16.8
function Counter(props) {
  let [count, setCount] = React.useState(props.count); // set initialState its returns array

  let IncCount = () => {
    count = count + 1;
    setCount(count);
  };
  return (
    <>
      <h1>{count}</h1>
      <button onClick={IncCount}>Inc Counter</button>
    </>
  ); // JSX Javascript XML
}

export default Counter;
