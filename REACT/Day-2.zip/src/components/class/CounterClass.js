import React from "react";

class CounterClass extends React.Component {
  constructor(props) {
    super();
    this.state = {
      count: props.count,
    };

    console.log(props);
    console.log("init");
  }

  componentDidMount() {
    //this.setState({ count: this.props.count });
  }

  componentDidUpdate() {
    console.log("componentDidUpdate");
  }

  incCounter = () => {
    let { count } = this.state;
    let newCount = {
      count: count + 1,
    };
    this.setState(newCount);
  };

  render() {
    console.log("render");
    return (
      <>
        <h1>{this.state.count}</h1>
        <button onClick={this.incCounter}>Click</button>
      </>
    );
  }
}

export default CounterClass;
