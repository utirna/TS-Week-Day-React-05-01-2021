import React from "react";

function App() {
  return (
    <>
      <h1>This is a text</h1>
      <h1>This is a text</h1>
    </>
  ); // JSX Javascript XML
}

export default App;
