import React from "react";
// hooks  ---> useState 16.8
function App() {
  let [count, updateSateValue] = React.useState(6); // set initialState its returns array

  /* let stateValue = state[0]
  let updateSateValue  = state[1];*/

  // [ stateValue, updateSateValue ]
  let IncCount = () => {
    count = count + 1;
    updateSateValue(count);
  };
  return (
    <>
      <h1>{count}</h1>
      <h1>{count}</h1>
      <button onClick={IncCount}>Inc Counter</button>
    </>
  ); // JSX Javascript XML
}

export default App;
