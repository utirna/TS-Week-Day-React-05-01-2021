import React from "react";

function App() {
  let text = "Testing Shastra";
  let printText = function () {
    return text;
  };

  return (
    <>
      <h1>{text + text}</h1>
      <h1>
        {text}
        {text}
      </h1>
      <h1>{Number("4") + (4 / 4) * 16}</h1>
      <h1>{printText()}</h1>
    </>
  ); // JSX Javascript XML
}

export default App;
