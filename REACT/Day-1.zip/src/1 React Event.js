import React from "react";

function App() {
  let text = "Testing Shastra";

  let printText = () => {
    console.log("click");
  };

  let inputChange = () => {
    console.log("input changed");
  };

  return (
    <>
      <h1>{text + text}</h1>
      <button onClick={printText}>CLICK</button>
      <input onChange={inputChange} />
    </>
  ); // JSX Javascript XML
}

export default App;
