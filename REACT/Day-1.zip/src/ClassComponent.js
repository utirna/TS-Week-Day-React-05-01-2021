import React, { Component } from "react";

class App extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <>
        <h1>This is a text</h1>
        <h1>This is a text</h1>
      </>
    ); // JSX Javascript XML
  }
}

export default App;
