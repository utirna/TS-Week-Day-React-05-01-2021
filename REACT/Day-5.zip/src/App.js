import { Formik, Form, Field } from "formik";
import React, { useState } from "react";

function App() {
  let [studentList, setStudentList] = useState([]);
  let initialValues = {
    sName: "",
    sCourse: "",
    sGender: "",
    sTech: [],
  };

  let onSubmit = (values) => {
    let _studentList = [...studentList];
    _studentList.push(values);
    setStudentList(_studentList);
  };

  return (
    <>
      <Formik initialValues={initialValues} onSubmit={onSubmit}>
        <Form className="form">
          <div>
            <label>Student Name*</label>
            <Field
              className="form-control"
              name="sName"
              type="text"
              placeholder="Enter Student Name"
            />
          </div>
          <div>
            <label>Gender*</label>
            <div>
              <Field name="sGender" type="radio" value="male" />
              <label>Male</label>

              <Field name="sGender" type="radio" value="female" />
              <label>Female</label>

              <Field name="sGender" type="radio" value="other" />
              <label>Other</label>
            </div>
          </div>
          <div>
            <label>Course*</label>
            <Field as="select" name="sCourse" className="form-control">
              <option value="">---- Select A Course ---</option>
              <option value="JavaScript">JavaScript</option>
              <option value="React JS">React JS</option>
              <option value="FSD Internship">FSD Internship</option>
            </Field>
          </div>
          <div>
            <label>Technology Area*</label>
            <div>
              <Field name="sTech" type="checkbox" value="HTML" />
              <label>HTML</label>

              <Field name="sTech" type="checkbox" value="CSS" />
              <label>CSS</label>

              <Field name="sTech" type="checkbox" value="JS" />
              <label>JS</label>

              <Field name="sTech" type="checkbox" value="NODE" />
              <label>NODE</label>
            </div>
          </div>
          <button type="submit">Save Student</button>
        </Form>
      </Formik>
    </>
  );
}
// useContext hooks states
// redux lib states
export default App;
