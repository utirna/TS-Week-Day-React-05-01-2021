import { Formik, Form, Field, ErrorMessage } from "formik";
import React, { useState } from "react";
import * as yup from "yup";

function App() {
  let [studentList, setStudentList] = useState([]);
  let initialValues = {
    sName: "",
    sCourse: "",
    sGender: "",
    sTech: ["HTML"],
  };

  let validationSchema = yup.object().shape({
    sName: yup
      .string()
      .min(3, "Please enter Student Name At lest 3 characters")
      .max(10, "Invalid Name Passed")
      .required("Enter Student Name"),
    sCourse: yup.string().required("Select a course"),
    sGender: yup.string().required("Gender not marked"),
    sTech: yup.array().min(2, "Choose one more."),
  });

  // let validate = (values) => {
  //   let error = {};
  //   if (values.sName === "") {
  //     error["sName"] = "Enter Student Name";
  //   } else if (values.sName.length <= 3) {
  //     error["sName"] = "AtLeast 3 Characters must be there";
  //   }

  //   if (values.sGender === "") {
  //     error["sGender"] = "Choose a gender";
  //   }

  //   if (values.sCourse === "") {
  //     error["sCourse"] = "Please select a course";
  //   }

  //   if (values.sTech.length === 0) {
  //     error["sTech"] = "At list one tech must be checked";
  //   }
  //   return error;
  // };

  let onSubmit = (values, onSubmitProps) => {
    let _studentList = [...studentList];
    _studentList.push(values);
    setStudentList(_studentList);
    onSubmitProps.resetForm(); // resetting
  };

  let removeStudent = (index) => {
    console.log(index);
    let _studentList = [...studentList];
    _studentList.splice(index, 1);
    setStudentList(_studentList);
  };
  return (
    <>
      <Formik
        initialValues={initialValues}
        onSubmit={onSubmit}
        validationSchema={validationSchema}
      >
        <Form className="form">
          <div>
            <label>Student Name*</label>
            <Field
              className="form-control"
              name="sName"
              type="text"
              placeholder="Enter Student Name"
              autoComplete="off"
            />
            <ErrorMessage
              name="sName"
              component="span"
              className="input-error"
            />
          </div>
          <div>
            <label>Gender*</label>
            <div>
              <Field name="sGender" type="radio" value="male" />
              <label>Male</label>

              <Field name="sGender" type="radio" value="female" />
              <label>Female</label>

              <Field name="sGender" type="radio" value="other" />
              <label>Other</label>
            </div>
            <ErrorMessage
              name="sGender"
              className="input-error"
              component="span"
            />
          </div>
          <div>
            <label>Course*</label>
            <Field as="select" name="sCourse" className="form-control">
              <option value="">---- Select A Course ---</option>
              <option value="JavaScript">JavaScript</option>
              <option value="React JS">React JS</option>
              <option value="FSD Internship">FSD Internship</option>
            </Field>
            <ErrorMessage
              name="sCourse"
              className="input-error"
              component="span"
            />
          </div>
          <div>
            <label>Technology Area*</label>
            <div>
              <Field name="sTech" type="checkbox" value="HTML" disabled />
              <label>HTML</label>

              <Field name="sTech" type="checkbox" value="CSS" />
              <label>CSS</label>

              <Field name="sTech" type="checkbox" value="JS" />
              <label>JS</label>

              <Field name="sTech" type="checkbox" value="NODE" />
              <label>NODE</label>
            </div>
            <ErrorMessage
              name="sTech"
              className="input-error"
              component="span"
            />
          </div>
          <button type="submit">Save Student</button>
        </Form>
      </Formik>

      <table className="table">
        <thead>
          <tr>
            <th>Sr No</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Applied Course</th>
            <th>Tech Interest</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {studentList.map((student, index) => {
            return (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{student.sName}</td>
                <td className="capitalize">{student.sGender}</td>
                <td>{student.sCourse}</td>
                <td>{student.sTech.join(" , ")}</td>
                <td>
                  <button onClick={() => removeStudent(index)}>DEL</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
}
// useContext hooks states
// redux lib states
export default App;
