import React, { useRef, useState } from "react";

function App() {
  //let sName = useRef();
  //let sCourse = useRef();
  let initValue = {
    sName: "",
    sCourse: "",
  };

  let [newStudent, setNewStudent] = useState(initValue);
  let [studentList, setStudentList] = useState([]);

  let saveNewStudent = (event) => {
    event.preventDefault();
    //console.log(sName.current.value);
    //console.log(sCourse.current.value);
    console.log(newStudent);

    let _studentList = [...studentList];
    _studentList.push(newStudent);
    setStudentList(_studentList);
    setNewStudent(initValue);
  };

  let inputChange = (event) => {
    let _value = event.target.value;
    let _name = event.target.name;

    let _newStudent = { ...newStudent };
    _newStudent[_name] = _value;
    setNewStudent(_newStudent);
  };

  return (
    <>
      <form onSubmit={saveNewStudent}>
        <div>
          <label>Student Name</label>
          <input
            // ref={sName}
            value={newStudent.sName}
            type="text"
            placeholder="Enter Student Name"
            onChange={inputChange}
            name="sName"
          />
        </div>
        <div>
          <label>Select Course</label>
          <select
            //ref={sCourse}
            name="sCourse"
            value={newStudent.sCourse}
            onChange={inputChange}
          >
            <option value="">---- Select A Course ---</option>
            <option value="JavaScript">JavaScript</option>
            <option value="React JS">React JS</option>
            <option value="FSD Internship">FSD Internship</option>
          </select>
        </div>
        <button>Save Student</button>
      </form>

      <table border="1">
        <thead>
          <tr>
            <th>Sr No</th>
            <th>Name</th>
            <th>Course</th>
          </tr>
        </thead>
        <tbody>
          {studentList.map((student, index) => {
            return (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{student.sName}</td>
                <td>{student.sCourse}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  ); // JSX Javascript XML
}
// useContext hooks states
// redux lib states
export default App;
